See **[xmonad](https://github.com/antoniosarosi/dotfiles/tree/master/.xmonad)**
for more info.
