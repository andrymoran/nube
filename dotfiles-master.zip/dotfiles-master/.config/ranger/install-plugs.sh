git clone https://github.com/alexanderjeurissen/ranger_devicons ~/.config/ranger/plugins
