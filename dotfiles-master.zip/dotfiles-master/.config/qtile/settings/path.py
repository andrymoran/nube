from os import path

qtile_path = path.join(path.expanduser('~'), ".config", "qtile")
