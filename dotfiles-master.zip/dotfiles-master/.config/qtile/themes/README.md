A theme consists of a simple json file. You can create your own by copying this
json object and changing values:

```json
{
    "dark": [
        "#0f101a",
        "#0f101a"
    ],
    "grey": [
        "#353c4a",
        "#353c4a"
    ],
    "light": [
        "#f1ffff",
        "#f1ffff"
    ],
    "text": [
        "#0f101a",
        "#0f101a"
    ],
    "focus": [
        "#a151d3",
        "#a151d3"
    ],
    "active": [
        "#f1ffff",
        "#f1ffff"
    ],
    "inactive": [
        "#4c566a",
        "#4c566a"
    ],
    "urgent": [
        "#F07178",
        "#F07178"
    ],
    "color1": [
        "#a151d3",
        "#a151d3"
    ],
    "color2": [
        "#F07178",
        "#F07178"
    ],
    "color3": [
        "#fb9f7f",
        "#fb9f7f"
    ],
    "color4": [
        "#ffd47e",
        "#ffd47e"
    ]
}

```
