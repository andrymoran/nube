# Alacritty

Checkout **[pycritty](https://github.com/antoniosarosi/pycritty)**

![Alacritty](./alacritty.png)
